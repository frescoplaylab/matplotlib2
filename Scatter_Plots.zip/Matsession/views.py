#from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, get_object_or_404


def displayimage1(request):

    return render(request, 'Matsession/myplot1.html')

def displayimage2(request):

    return render(request, 'Matsession/myplot2.html')

def displayimage3(request):

    return render(request, 'Matsession/myplot3.html')