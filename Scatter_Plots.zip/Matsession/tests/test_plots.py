import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.testing.decorators import image_comparison

@image_comparison(baseline_images=['Sine_Wave_Plot'],extensions=['png'])
def test_sine_wave_plot():

    # Write your functionality below
    

@image_comparison(baseline_images=['Multi_Curve_Plot'],extensions=['png'])
def test_multi_curve_plot():

    # Write your functionality below


@image_comparison(baseline_images=['Scatter_Plot'],extensions=['png'])
def test_scatter_plot():

    # Write your functionality below

